import userModel from "../models/userModel.js";
import jwt from "jsonwebtoken";
import { comparePassword, hashPassword } from "../helpers/authEncryption.js";

// * register handler
const JWT_SECRET = "asdfghjkl12345678";
export const createAdmin = async (req, res) => {
  try {
    const { name, email, password, phone, emailPassword,role,gst,shop,Latitude,Longitude,address,id,accountNumber,ifscCode,bankName,userName,coAccountNumber } = req.body;

    // if ((!phone || !email) && !name) {
    //   return res.send({ message: "All fields are required" });
    // }

    // * Check if the use already exists or not
    if (email) {
      const existingUser = await userModel.findOne({ email });

      if (existingUser) {
        return res.status(400).send({
          success: false,
          message: "This email already exists",
        });
      }
    } else if (phone) {
      const existingPhone = await userModel.findOne({ phone });

      if (existingPhone) {
        return res.status(400).send({
          success: false,
          message: "This phone number already exists",
        });
      }
    }

    const user = new userModel({
      id,
      name,
      email,
      phone,
      role,
      gst,
      shop,
      address,
    Latitude,
    Longitude,
    accountNumber,
    ifscCode,
    bankName,
    userName,
    coAccountNumber
    });
    // * Registering the user
// console.log("user ",user.Latitude)
    if (!password) {
      const hashedEmailPass = await hashPassword(emailPassword);
      user.emailPassword = hashedEmailPass;
    }
    if (!emailPassword) {
      const hashedPass = await hashPassword(password);
      user.password = hashedPass;
    }

    // * saving the user

    await user.save();

    // * creating token
    const token = jwt.sign({ _id: user._id }, JWT_SECRET, {
      expiresIn: "7d",
    });

    res.status(201).send({
      success: true,
      message: "Registered Successfully",
      _id: user._id,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        address: user.address,
        role: user.role,
        location: user.location,
        cart: user.cart,
        gst: user.gst,
        shop: user.shop,
        Latitude: user.Latitude,
        Longitude: user.Longitude,
        address: user.address,
        id:user.id,
        accountNumber:user.accountNumber,
        ifscCode:user.ifscCode,
        bankName:user.bankName,
        userName:user.userName,
        coAccountNumber:user.coAccountNumber
      },

      token,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Registration failed due internal server error",
      msg:error.message
    });
  }
};
export const createMerchant = async (req, res) => {
  try {
    const { name, email, password, phone, emailPassword,gst,shop,Latitude,Longitude,address,id,accountNumber,ifscCode,bankName,userName,coAccountNumber } = req.body;

    // if ((!phone || !email) && !name) {
    //   return res.send({ message: "All fields are required" });
    // }

    // * Check if the use already exists or not
    if (email) {
      const existingUser = await userModel.findOne({ email });

      if (existingUser) {
        return res.status(400).send({
          success: false,
          message: "This email already exists",
        });
      }
    } else if (phone) {
      const existingPhone = await userModel.findOne({ phone });

      if (existingPhone) {
        return res.status(400).send({
          success: false,
          message: "This phone number already exists",
        });
      }
    }

    const user = new userModel({
      id,
      name,
      email,
      phone,
      gst,
      shop,
      address,
    Latitude,
    Longitude,
    accountNumber,
    ifscCode,
    bankName,
    userName,
    coAccountNumber
    });
    // * Registering the user
// console.log("user ",user.Latitude)
    if (!password) {
      const hashedEmailPass = await hashPassword(emailPassword);
      user.emailPassword = hashedEmailPass;
    }
    if (!emailPassword) {
      const hashedPass = await hashPassword(password);
      user.password = hashedPass;
    }

    // * saving the user

    await user.save();

    // * creating token
    const token = jwt.sign({ _id: user._id }, JWT_SECRET, {
      expiresIn: "7d",
    });

    res.status(201).send({
      success: true,
      message: "Registered Successfully",
      _id: user._id,
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        address: user.address,
        role: user.role,
        location: user.location,
        cart: user.cart,
        gst: user.gst,
        shop: user.shop,
        Latitude: user.Latitude,
        Longitude: user.Longitude,
        address: user.address,
        id:user.id,
        accountNumber:user.accountNumber,
        ifscCode:user.ifscCode,
        bankName:user.bankName,
        userName:user.userName,
        coAccountNumber:user.coAccountNumber
      },

      token,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "Registration failed due internal server error",
      msg:error.message
    });
  }
};

// * Login Handler
export const loginController = async (req, res) => {
  try {
    const { email, phone, password, emailPassword } = req.body;

    let user;

    if (email) {
      user = await userModel.findOne({ email }).lean();
    } else if (phone) {
      user = await userModel.findOne({ phone }).lean();
    }
    if (!user) {
      return res.status(400).send({ message: "User does not exist" });
    }

    if (emailPassword !== undefined) {
      const match = await comparePassword(emailPassword, user.emailPassword);
      if (!match) {
        return res.status(400).send({ message: "Wrong Password" });
      }
    } else {
      const match = await comparePassword(password, user.password);
      if (!match) {
        return res.status(400).send({ message: "Wrong Password" });
      }
    }

    const token = jwt.sign({ _id: user._id }, JWT_SECRET, {
      expiresIn: "7d",
    });

    res.status(200).send({
      success: true,
      message: "Login Successfully",
      user: {
        _id: user._id,
        name: user.name,
        email: user.email,
        phone: user.phone,
        role: user.role,
        address: "KA India",
        altPhone: user.altPhone,
        location: user.location,
        cart: user.cart,
        gst: user.gst,
        shop: user.shop,
        Latitude: user.Latitude,
        Longitude: user.Longitude,
        address: user.address,
        id:user.id,
        accountNumber:user.accountNumber,
        ifscCode:user.ifscCode,
        bankName:user.bankName,
        userName:user.userName,
        coAccountNumber:user.coAccountNumber,
        termsAccepted:user.termsAccepted,
        termsAcceptedDate:user.termsAcceptedDate,
        termsAndConditions:user.termsAndConditions
      },   
      token,
    }); 
  } catch (error) {
    res.status(500).send({
      success: false,
      message: error.message,
      error,
    });
  }
};
// * Forgot password controller
export const resetPasswordController = async (req, res) => {
  try {
    const { email, newPassword } = req.body;

    // Find the user by email or phone
    let user;
    if (email) {
      user = await userModel.findOne({ email });
    } 
    if (!user) {
      return res.status(400).json({ success: false, message: "User not found" });
    }

    // Hash the new password before saving
    const hashedPassword = await hashPassword(newPassword);

    // Update the password in the database
    if (email) {
      user.emailPassword = hashedPassword;
    } 

    await user.save();

    res.status(200).json({ success: true, message: "Password updated successfully" });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
};

// * Getting single user
export const getUserController = async (req, res) => {
  try {
    const { id } = req.params;
    const user = await userModel.findById(id);

    res.status(200).send({
      success: true,
      user,
    });
  } catch (error) {
    res.status(500).send({
      message: "internal server error",
    });
  }
};

// * This function will update the user data
export const updateProfileController = async (req, res) => {
  try {
    const { accountNumber,ifscCode,bankName,userName,coAccountNumber } =
      req.body
      
    const user = await userModel.findById(req.user._id);
    if(accountNumber !== coAccountNumber){
      return res.status(400).send({
        success: false,
        message: "Account number does not match",
      });
    }
    

    if (accountNumber) { 
      user.accountNumber = accountNumber;
    }
    if (ifscCode) { 
      user.ifscCode = ifscCode;
    }
    if (bankName) { 
      user.bankName = bankName;
    }
    if(userName){
      user.userName = userName;
    }
    if(coAccountNumber){
      user.coAccountNumber = coAccountNumber;
    }

    await user.save();

    res.status(200).send({
      success: true,
      message: "Profile Updated Successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "internal server error",
    });
  }
};

export const updateTermsAndConditions = async (req, res) => {
  try {
    const { termsAccepted,termsAcceptedDate,termsAndConditions } =
      req.body
      
    const user = await userModel.findById(req.user._id);
  
    

    if (termsAccepted) {
      user.termsAccepted = termsAccepted;
    }
    if (termsAcceptedDate) {
      user.termsAcceptedDate = termsAcceptedDate;
    }
    if (termsAndConditions) {
      user.termsAndConditions = termsAndConditions;
    }

    await user.save();

    res.status(200).send({
      success: true,
      message: "Profile Updated Successfully",
      user,
    });
  } catch (error) {
    console.log(error);
    res.status(500).send({
      success: false,
      message: "internal server error",
    });
  }
};

// * This function will get all the users for admin purpose
export const getUsersListController = async (req, res) => {
  try {
    const users = await userModel.find().lean();

    res.status(200).send({
      success: true,
      count: users.length,
      users,
    });
  } catch (error) {
    res.status(500).send({
      success: false,
      message: "internal server error",
    });
  }
};
// this is the fucntion is used the get the k users
export const getkUsers = async (req, res) => {
    const { page = 1, limit = 10 } = req.query;
  
    const pageNumber = Math.max(1, Number(page));
    const limitNumber = Math.min(Math.max(1, Number(limit)), 100);
  
  
    try {
      const users = await userModel
        .find()
        .skip((pageNumber - 1) * limitNumber)
        .limit(limitNumber)
        .sort({ createdAt: -1 })
        .lean();
  
      const totalUsers = await userModel.countDocuments();
  
      res.json({
        users,
        totalUsers,
        currentPage: pageNumber,
        totalPages: Math.ceil(totalUsers / limitNumber),
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  };
  
  export const deleteUser = async (req, res) => {
    try {
      const users = await userModel
        .findByIdAndDelete(req.params.id)
  
      res.status(201).send({
        success: true,
        message: "User deleted successfully",
        users,
      });
    } catch (error) {
      res.status(500).send({
        success: false,
        message: error.message,
      });
    }
  };


export const getCustomUserId = async (req, res) => {
    try {
      const users = await userModel.find({}, "id").lean();
      const ids = users.map((user) => user.id);
      res.json({ success: true, data: ids });
    } catch (error) {
      res.status(500).send("Internal Server Error");
    }
  };